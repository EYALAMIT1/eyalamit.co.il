<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-pricing-table/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-pricing-table/advanced-pricing-table.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-pricing-table/options-map/map.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-pricing-table/custom-styles/custom-styles.php';