<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/testimonial-carousel/options-map/map.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/testimonial-carousel/custom-styles/custom-styles.php';