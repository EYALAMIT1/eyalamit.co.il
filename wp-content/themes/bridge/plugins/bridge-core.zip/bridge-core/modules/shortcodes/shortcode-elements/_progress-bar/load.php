<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_progress-bar/progress-bar.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_progress-bar/custom-styles/custom-styles.php';