<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/accordions/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/accordions/accordion.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/accordions/accordion-tab.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/accordions/custom-styles/custom-styles.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/accordions/options-map/map.php';
