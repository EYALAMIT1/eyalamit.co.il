<div class="qode-controls">
    <div class="qode-controls-navigate">
        <span class="qode-control-button qode-control-button-next lnr lnr-chevron-right">

        </span>
        <span class="qode-control-button qode-control-button-prev lnr lnr-chevron-left">

        </span>
    </div>
</div><!--  /controls -->
<span class="qode-control-button qode-control-button-back lnr lnr-arrow-left"></span>