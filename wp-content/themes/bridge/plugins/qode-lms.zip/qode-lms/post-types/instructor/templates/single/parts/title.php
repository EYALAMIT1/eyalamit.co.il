<?php if ( ! empty( $title ) ) { ?>
	<p class="qode-title">
		<?php echo esc_html( $title ); ?>
	</p>
<?php } ?>