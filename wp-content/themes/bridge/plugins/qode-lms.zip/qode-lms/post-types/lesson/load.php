<?php

include_once QODE_LMS_CPT_PATH . '/lesson/lesson-register.php';
include_once QODE_LMS_CPT_PATH . '/lesson/helper-functions.php';